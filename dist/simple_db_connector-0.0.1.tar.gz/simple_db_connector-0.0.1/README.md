# Simple_Python_DB_Connector

Python module for simple connection and editing of databases.
