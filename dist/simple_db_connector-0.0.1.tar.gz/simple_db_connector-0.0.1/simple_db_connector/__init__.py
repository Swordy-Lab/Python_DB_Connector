import mysql.connector
import os
import json
import logging
import uuid
from simple_db_connector import database